//
//  RecipeDetailVC.swift
//  Food
//
//  Created by Anbarasan Nadarajan on 23/09/19.
//  Copyright © 2019 Anbarasan Nadarajan. All rights reserved.
//

import UIKit

class RecipeDetailVC: UIViewController {

    @IBOutlet weak var recipeInstruction: UILabel!
    @IBOutlet weak var recipeImg: UIImageView!
    @IBOutlet weak var recipeTitle: UILabel!
    
    var selectedRecipe : Recipe!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        recipeImg.image = UIImage(named: selectedRecipe.imageName)
        recipeTitle.text = selectedRecipe.title
        recipeInstruction.text = selectedRecipe.instructions
    }
    

}
