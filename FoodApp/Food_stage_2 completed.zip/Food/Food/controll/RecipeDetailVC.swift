//
//  RecipeDetailVC.swift
//  Food
//
//  Created by Anbarasan Nadarajan on 23/09/19.
//  Copyright © 2019 Anbarasan Nadarajan. All rights reserved.
//

import UIKit

class RecipeDetailVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
