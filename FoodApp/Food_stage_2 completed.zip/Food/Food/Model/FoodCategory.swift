//
//  FoodCategory.swift
//  Food
//
//  Created by Anbarasan Nadarajan on 22/09/19.
//  Copyright © 2019 Anbarasan Nadarajan. All rights reserved.
//

import Foundation

struct FoodCategory{
    var title       : String
    var imageName   : String
}
