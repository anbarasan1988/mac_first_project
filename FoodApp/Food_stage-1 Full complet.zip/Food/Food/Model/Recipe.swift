//
//  Recipe.swift
//  Food
//
//  Created by Anbarasan Nadarajan on 22/09/19.
//  Copyright © 2019 Anbarasan Nadarajan. All rights reserved.
//

import Foundation
struct Recipe {
    var title       : String
    var instructions: String
    var imageName   : String
}
